package lockedMepackage;


import java.io.*;
import java.util.*;


public class LockedMeClass 
{
		static final String filesPath ="D:\\Kiran\\LockedMeFiles";
		static final String errorMessage="Error Occurred. Please Contact admin@Lockedme.com";
		static Scanner obj = new Scanner(System.in);
		public static void main(String[] args)
		{
			int ch;
			do
			{
				displayMenu();
				System.out.println("\n Please enter your Choice");
				ch=Integer.parseInt(obj.nextLine());
				
				switch(ch)
				{
				case 1:displayAllFiles();
				break;
				case 2:addNewFiles();
				break;
				case 3:deleteFiles();
				break;
				case 4:searchFiles();
				break;
				case 5:System.exit(0);
				break;
				default:System.out.println("Please choose valid option");
			}
						}
				while(ch>0);
				obj.close();
			
		
				
		}
		/**
		 * This function will display the Welcome page
		 */
		
		public static void displayMenu()
		{
			System.out.println("=========================================================");
			System.out.println("\t \t Welcome to LockedMe.com \t");
			System.out.println("=========================================================");
			System.out.println("\t \t Please Choose your Option\t \n");
			System.out.println("\t 1. Display All Files from the Directory.");
			System.out.println("\t 2. Create new File in the Directory.");
			System.out.println("\t 3. Delete a File from the Directory.");
			System.out.println("\t 4. Search a File from the Directory.");
			System.out.println("\t 5. Exit. \n\n");
			System.out.println("\t\t        Developed by");
			System.out.println("\t\t    Nanubolu Sai Surya Kiran.");
			System.out.println("\t\tEmail: kirannanubolu@gmail.com \n\n");
					
		}
		
		
		/**
		 * This Method Displays all the Files in the Directory
		 */
		
		public static void displayAllFiles()
		{
			try
			{
			File folder= new File(filesPath);
			File[] listOfFiles=folder.listFiles();
			
			if(listOfFiles.length==0)
			{
				System.out.println("No Files Exist in the Directory");
			}
			else
			{
				System.out.println("The Below are the files Present : \n ");
				for(var l: listOfFiles)
				{
					System.out.println(l.getName());
				}
			}
			}
			catch(Exception Ex) {
				System.out.println(errorMessage);
			}
		}
		public static void addNewFiles()
		{
			try
			{
				String fileName;
				System.out.println("Please enter the file Name");
				fileName = obj.nextLine();
				
				File folder= new File(filesPath);
				File[] listOfFiles=folder.listFiles();
				
				LinkedList<String> filenames=new LinkedList<String>();
				
				for(var l: listOfFiles)
					filenames.add(l.getName());
				
				if(filenames.contains(fileName))
					{
					System.out.println("File already exists. Please give another name");
					
					}
				else
					{
						int linescount;
						System.out.println("Please enter the number of lines to be created");
						linescount = Integer.parseInt(obj.nextLine());
					
					FileWriter fw= new FileWriter(filesPath+"\\"+fileName);
						for(int i=1;i<=linescount;i++)
						{
							System.out.println("Enter the Data to be stored in line : "+i);
							fw.write(obj.nextLine()+"\n");
						}
						System.out.println("\t"+fileName + " File Created Successfully");
				fw.close();
				
			}
			}
			catch(Exception Ex)
			{
				System.out.println(errorMessage);
			}
			
		}
		
		/**
		 * This function Deletes the file as per the user
		 */
		public static void deleteFiles()
		{
			
			try 
			{
				String fileName;			
				System.out.println("\n Enter the file name to be deleted \n");
				fileName=obj.nextLine();			
				
				File file= new File(filesPath+"\\"+fileName);
				if (file.exists()) 			
						{	
						file.delete();
						System.out.println("File is deleted successfully ");	
						}
						else 
							System.out.println("File doesnot exist");
			}
			catch(Exception Ex) 
			{
				System.out.println(errorMessage);
			}
		
		}
		
		/**
		 * This Method will search the file and display the contents of it based on user
		 */
		public static void searchFiles()
		{
		
			try
			{
				String fileName;
				System.out.println("\n Enter the file name to be searched ");
				fileName=obj.nextLine();
				
			File folder= new File(filesPath);
			File[] listOfFiles=folder.listFiles();
			
			LinkedList<String> filenames=new LinkedList<String>();
			
			for(var l: listOfFiles)
				filenames.add(l.getName());
			
			if(filenames.contains(fileName))
			{
				System.out.println("\n File is found \n ");
				}
			else
				System.out.println("\n File is not found");
			
			}
			catch(Exception Ex) {
				System.out.println(errorMessage);
			}
		
		}
		
	}
